# Theros Cloner
Clone any app up to 5 times (one per category) with separate accounts/data.

* Engine: BlackBox (cloned from GitHub during the build) - this folder only holds our app on top of it.
* `overlay/`  our app (Java). `merge.sh` drops it into the engine and adds Shizuku.
* `debug.keystore`  permanent signing key (copied to ~/.android/ by the workflow) so every update installs over the last one.
  Keep a copy of it. Reuse it for your other apps too.

Background modes: Native Unrestricted (always), Shizuku Layer (optional toggle), Root (auto).
