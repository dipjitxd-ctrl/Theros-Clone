#!/usr/bin/env python3
"""
Makes the cloned apps see the phone's REAL Google Play services.
Patches the engine's PackageManager hook: when a clone asks about Google's packages,
the question is passed straight to the real Android system instead of the virtual one.
Never breaks the build: if the hook isn't found it only reports that.
"""
import glob, os, re, sys

eng = sys.argv[1] if len(sys.argv) > 1 else "engine"
summary = os.environ.get("GITHUB_STEP_SUMMARY")


def note(t):
    print(t)
    if summary:
        with open(summary, "a", encoding="utf-8") as f:
            f.write(t + "\n")


note("## Google pass-through patch")
files = [p for p in glob.glob(eng + "/**/*.java", recursive=True) if p.endswith("IPackageManagerProxy.java")]
if not files:
    cands = []
    for p in glob.glob(eng + "/Bcore/**/*.java", recursive=True):
        try:
            if '"getPackageInfo"' in open(p, encoding="utf-8", errors="ignore").read():
                cands.append(p)
        except Exception:
            pass
    note("NOT patched: IPackageManagerProxy.java not found. Files mentioning getPackageInfo:")
    for c in cands[:8]:
        note("- " + c)
    sys.exit(0)

NAMES = {"getPackageInfo", "getApplicationInfo", "getPackageInfoVersioned",
         "GetPackageInfo", "GetApplicationInfo"}
sig = re.compile(r'(?:public|protected)\s+Object\s+hook\(\s*Object\s+(\w+)\s*,\s*Method\s+(\w+)\s*,\s*Object\s*\[\]\s+(\w+)\s*\)\s*throws\s+Throwable\s*\{')
tag = re.compile(r'@ProxyMethod\("(\w+)"\)|class\s+(\w+)\s+extends')

total = 0
for f in files:
    s = open(f, encoding="utf-8").read()
    out, last, n = [], 0, 0
    for m in sig.finditer(s):
        back = s[max(0, m.start() - 900):m.start()]
        tags = tag.findall(back)
        if not tags:
            continue
        name = tags[-1][0] or tags[-1][1]
        if name not in NAMES:
            continue
        who, meth, args = m.group(1), m.group(2), m.group(3)
        inject = (
            "\n        /* Theros: let clones see the phone's real Google services */\n"
            "        { Object[] __a = " + args + "; if (__a != null && __a.length > 0 && __a[0] instanceof String) {"
            " String __p = (String) __a[0];"
            " if (__p.equals(\"com.google.android.gms\") || __p.equals(\"com.google.android.gsf\")"
            " || __p.equals(\"com.android.vending\") || __p.startsWith(\"com.google.android.gms.\")) {"
            " try { Object __r = " + meth + ".invoke(" + who + ", __a); if (__r != null) return __r; }"
            " catch (Throwable __t) { } } } }\n"
        )
        out.append(s[last:m.end()])
        out.append(inject)
        last = m.end()
        n += 1
    out.append(s[last:])
    if n:
        open(f, "w", encoding="utf-8").write("".join(out))
        total += n
        note("patched %d hook(s) in %s" % (n, os.path.basename(f)))
if total == 0:
    note("NOT patched: found %s but no getPackageInfo/getApplicationInfo hook matched." % os.path.basename(files[0]))
    # show the hook names we did see so the patch can be adapted
    s = open(files[0], encoding="utf-8").read()
    seen = re.findall(r'@ProxyMethod\("(\w+)"\)', s)[:25]
    note("hooks seen: " + ", ".join(seen))
else:
    note("OK: clones now ask the real system about Google packages.")
