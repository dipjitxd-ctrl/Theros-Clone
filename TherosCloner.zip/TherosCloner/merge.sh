#!/usr/bin/env bash
# Merges the Theros Cloner app into the BlackBox engine checkout.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ENG="${1:-engine}"
APP="$ENG/app"
[ -d "$APP" ] || { echo "engine/app not found - engine clone failed?"; exit 1; }

echo "Replacing engine demo app sources with Theros Cloner..."
rm -rf "$APP/src/main"
mkdir -p "$APP/src"
cp -r "$HERE/overlay/main" "$APP/src/main"

if [ -f "$APP/build.gradle" ]; then
  echo "Patching $APP/build.gradle (groovy)"
  cat >> "$APP/build.gradle" <<'GRADLE'

// ---- Theros Cloner additions ----
android {
    defaultConfig {
        applicationId "com.theros.cloner"
        versionCode 1
        versionName "1.0"
    }
}
dependencies {
    implementation 'dev.rikka.shizuku:api:13.1.5'
    implementation 'dev.rikka.shizuku:provider:13.1.5'
}
GRADLE
elif [ -f "$APP/build.gradle.kts" ]; then
  echo "Patching $APP/build.gradle.kts (kotlin dsl)"
  cat >> "$APP/build.gradle.kts" <<'GRADLE'

// ---- Theros Cloner additions ----
android {
    defaultConfig {
        applicationId = "com.theros.cloner"
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
GRADLE
else
  echo "No app/build.gradle found"; exit 1
fi
echo "Merge done."
