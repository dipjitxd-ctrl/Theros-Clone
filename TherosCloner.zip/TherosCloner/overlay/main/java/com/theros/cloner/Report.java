package com.theros.cloner;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/** Short text report the user can paste to get help (device, installed clones, crash lines). */
final class Report {
    static String build(Context c, int cat) {
        StringBuilder sb = new StringBuilder();
        sb.append("== Theros Cloner report ==\n");
        sb.append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            .append(" | Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")")
            .append(" | ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        sb.append("Category ").append(cat + 1).append(" contents:\n");
        List<String> have = Virtual.installed(cat);
        if (have.isEmpty()) sb.append("  (empty)\n");
        for (String p : have) {
            sb.append("  ").append(p);
            try {
                ApplicationInfo ai = c.getPackageManager().getApplicationInfo(p, 0);
                int n = ai.splitSourceDirs == null ? 0 : ai.splitSourceDirs.length;
                sb.append(" | target ").append(ai.targetSdkVersion).append(" | splits ").append(n);
            } catch (Throwable ignored) { }
            sb.append('\n');
        }
        sb.append("Google install log:\n").append(Virtual.googleLog.isEmpty() ? "  (not run)\n" : Virtual.googleLog);
        sb.append("Root: ").append(Shell.rootAvailable()).append(" | Shell mode: ").append(Shell.active()).append('\n');
        sb.append("\n== Crash / error lines (last) ==\n");
        Pattern pat = Pattern.compile("(FATAL EXCEPTION|AndroidRuntime|UnsatisfiedLink|Caused by|ClassNotFound|NoSuchMethod|"
            + "SecurityException|Permission Denial|dlopen|signal [0-9]+|Abort message|BlackBox|VirtualCore|"
            + "java\\.lang\\.[A-Za-z]*(Exception|Error))", Pattern.CASE_INSENSITIVE);
        List<String> hits = new ArrayList<String>();
        try {
            Process p = new ProcessBuilder("logcat", "-d", "-v", "time", "-t", "4000").redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String l;
            while ((l = br.readLine()) != null) {
                if (pat.matcher(l).find()) {
                    hits.add(l.length() > 200 ? l.substring(0, 200) : l);
                    if (hits.size() > 400) hits.remove(0);
                }
            }
        } catch (Throwable t) {
            hits.add("(could not read log: " + t + ")");
        }
        int from = Math.max(0, hits.size() - 60);
        for (int i = from; i < hits.size(); i++) sb.append(hits.get(i)).append('\n');
        if (hits.isEmpty()) sb.append("(none found)\n");
        return sb.toString();
    }
}
