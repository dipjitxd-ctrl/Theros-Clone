package com.theros.cloner;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final class Pal {
        int bg, card, text, sub, primary, onPrimary, line, chip, ok, warn, bad;
    }

    static boolean dark(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
            == Configuration.UI_MODE_NIGHT_YES;
    }

    static Pal pal(Context c) {
        boolean d = dark(c);
        Pal p = new Pal();
        p.bg = d ? 0xFF0D1117 : 0xFFF6F8FD;
        p.card = d ? 0xFF151B24 : 0xFFFFFFFF;
        p.text = d ? 0xFFE6EAF2 : 0xFF12161C;
        p.sub = d ? 0xFFA9B4C6 : 0xFF5A6575;
        p.primary = d ? 0xFF8AB4FF : 0xFF2563EB;
        p.onPrimary = d ? 0xFF06214F : 0xFFFFFFFF;
        p.line = d ? 0xFF283140 : 0xFFE3E8F1;
        p.chip = d ? 0xFF1E2633 : 0xFFEAEFF8;
        p.ok = d ? 0xFF6EE7A0 : 0xFF16A34A;
        p.warn = d ? 0xFFFBBF24 : 0xFFD97706;
        p.bad = d ? 0xFFFF8A80 : 0xFFD93025;
        return p;
    }

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static GradientDrawable rect(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static void skin(Context c, TextView t, int bg, int fg, float radiusDp) {
        t.setTextColor(fg);
        t.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33808080), rect(c, bg, radiusDp), null));
    }

    static TextView button(Context c, String s, int bg, int fg, View.OnClickListener l) {
        TextView t = tv(c, s, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        skin(c, t, bg, fg, 12);
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    static LinearLayout card(Context c, Pal p) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        l.setBackground(rect(c, p.card, 18));
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }
}
