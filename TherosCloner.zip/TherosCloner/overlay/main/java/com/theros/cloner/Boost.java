package com.theros.cloner;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

/** Applies every restriction bypass that root / Shizuku can reach. Unsupported ones just fail harmlessly. */
final class Boost {
    interface Done { void done(String log); }

    static String apply(Context c) {
        Shell.Mode m = Shell.active();
        if (m == Shell.Mode.NONE) return "Privileged layer is not active (no root, Shizuku off or not connected).";
        String pkg = c.getPackageName();
        int uid = c.getApplicationInfo().uid;
        String[] cmds = new String[]{
            "cmd deviceidle whitelist +" + pkg,
            "cmd appops set " + pkg + " RUN_IN_BACKGROUND allow",
            "cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow",
            "cmd appops set " + pkg + " SYSTEM_ALERT_WINDOW allow",
            "am set-standby-bucket " + pkg + " active",
            "cmd netpolicy add restrict-background-whitelist " + uid,
            "pm grant " + pkg + " android.permission.POST_NOTIFICATIONS",
            "settings put global settings_enable_monitor_phantom_procs false",
            "device_config set_sync_disabled_for_tests persistent",
            "device_config put activity_manager max_phantom_processes 2147483647",
            "settings put global cached_apps_freezer disabled"
        };
        StringBuilder sb = new StringBuilder("Mode: " + m + "\n\n");
        int ok = 0;
        for (String cmd : cmds) {
            Shell.Res r = Shell.run(cmd);
            boolean good = r.code == 0;
            if (good) ok++;
            sb.append(good ? "\u2713 " : "\u2717 ").append(cmd).append('\n');
            if (!good && r.out.length() > 0) {
                String first = r.out.split("\n")[0];
                if (first.length() > 90) first = first.substring(0, 90);
                sb.append("    ").append(first).append('\n');
            }
        }
        if (m == Shell.Mode.ROOT) {
            // root only: make our own processes very hard for the system to kill
            String oom = "ps -A -o PID,NAME | while read p n; do case \"$n\" in " + pkg
                + "*) echo -900 > /proc/$p/oom_score_adj;; esac; done";
            Shell.Res r = Shell.run(oom);
            sb.append(r.code == 0 ? "\u2713 " : "\u2717 ").append("protect processes from low-memory killer (root)\n");
            if (r.code == 0) ok++;
        }
        sb.append("\n").append(ok).append(" step(s) applied.");
        String log = sb.toString();
        Prefs.setLastLog(log);
        return log;
    }

    static void applyAsync(final Context c, final Done d) {
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override public void run() {
                final String log = apply(c);
                if (d != null) h.post(new Runnable() { @Override public void run() { d.done(log); } });
            }
        }).start();
    }
}
