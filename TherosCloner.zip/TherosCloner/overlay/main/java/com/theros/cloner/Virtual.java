package com.theros.cloner;

import android.content.pm.ApplicationInfo;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import top.niunaijun.blackbox.BlackBoxCore;

/** Everything that talks to the BlackBox engine lives here (category = virtual user id 0..4). */
final class Virtual {
    static final int CATS = 5;
    private static final String TAG = "TherosVirtual";

    private static Object core() { return BlackBoxCore.get(); }

    private static Class<?> wrap(Class<?> c) {
        if (!c.isPrimitive()) return c;
        if (c == int.class) return Integer.class;
        if (c == boolean.class) return Boolean.class;
        if (c == long.class) return Long.class;
        return c;
    }

    private static Object call(Object target, String name, Object... args) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            Class<?>[] pt = m.getParameterTypes();
            if (!m.getName().equals(name) || pt.length != args.length) continue;
            boolean ok = true;
            for (int i = 0; i < pt.length; i++) {
                if (!wrap(pt[i]).isInstance(args[i])) { ok = false; break; }
            }
            if (ok) return m.invoke(target, args);
        }
        throw new NoSuchMethodException(name);
    }

    private static String msg(Throwable t) {
        Throwable c = t;
        while (c.getCause() != null) c = c.getCause();
        String m = c.getMessage();
        return m == null ? c.getClass().getSimpleName() : m;
    }

    static List<String> installed(int cat) {
        List<String> out = new ArrayList<String>();
        try {
            Object r = call(core(), "getInstalledApplications", 0, cat);
            if (r instanceof List) {
                for (Object o : (List<?>) r) {
                    if (o instanceof ApplicationInfo) out.add(((ApplicationInfo) o).packageName);
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "installed() failed: " + msg(t));
        }
        return out;
    }

    private static void ensureUser(int cat) {
        try {
            Object users = call(core(), "getUsers");
            if (users instanceof List) {
                for (Object u : (List<?>) users) {
                    try {
                        Field id = u.getClass().getField("id");
                        if (id.getInt(u) == cat) return;
                    } catch (Exception ignored) { }
                }
            }
        } catch (Throwable ignored) { }
        try { call(core(), "createUser", cat); return; } catch (Throwable ignored) { }
        try {
            Method gm = BlackBoxCore.class.getMethod("getBUserManager");
            Object um = gm.invoke(null);
            call(um, "createUser", cat);
        } catch (Throwable ignored) { }
    }

    private static String resultError(Object r) {
        if (r == null) return null;
        try {
            Field s = r.getClass().getField("success");
            if (!s.getBoolean(r)) {
                try {
                    Field m = r.getClass().getField("msg");
                    Object v = m.get(r);
                    if (v != null) return String.valueOf(v);
                } catch (Exception ignored) { }
                return "Install failed";
            }
        } catch (NoSuchFieldException e) {
            try {
                Method ok = r.getClass().getMethod("isSuccess");
                Object v = ok.invoke(r);
                if (v instanceof Boolean && !((Boolean) v)) return "Install failed";
            } catch (Exception ignored) { }
        } catch (Exception ignored) { }
        return null;
    }

    /** returns null on success, otherwise an error message */
    static String install(String pkg, int cat) {
        try {
            ensureUser(cat);
            String err = resultError(call(core(), "installPackageAsUser", pkg, cat));
            if (err != null) return err;
            return installed(cat).contains(pkg) ? null : "Engine could not clone this app (it may use split APKs)";
        } catch (Throwable t) {
            return msg(t);
        }
    }

    static String installFile(File apk, int cat) {
        try {
            ensureUser(cat);
            String err = resultError(call(core(), "installPackageAsUser", apk, cat));
            return err;
        } catch (Throwable t) {
            return msg(t);
        }
    }

    static boolean launch(String pkg, int cat) {
        try {
            Object r = call(core(), "launchApk", pkg, cat);
            return !(r instanceof Boolean) || (Boolean) r;
        } catch (Throwable t) {
            Log.w(TAG, "launch failed: " + msg(t));
            return false;
        }
    }

    static void remove(String pkg, int cat) {
        try { call(core(), "uninstallPackageAsUser", pkg, cat); return; } catch (Throwable ignored) { }
        try { call(core(), "uninstallPackage", pkg, cat); } catch (Throwable ignored) { }
    }
}
