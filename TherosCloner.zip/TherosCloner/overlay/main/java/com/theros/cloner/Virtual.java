package com.theros.cloner;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import java.util.List;

import top.niunaijun.blackbox.BlackBoxCore;

/** Everything that talks to the BlackBox engine lives here (category = virtual user id 0..4). */
final class Virtual {
    static final int CATS = 5;
    private static final String TAG = "TherosVirtual";

    private static Object core() { return BlackBoxCore.get(); }

    private static Class<?> wrap(Class<?> c) {
        if (!c.isPrimitive()) return c;
        if (c == int.class) return Integer.class;
        if (c == boolean.class) return Boolean.class;
        if (c == long.class) return Long.class;
        return c;
    }

    private static Object call(Object target, String name, Object... args) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            Class<?>[] pt = m.getParameterTypes();
            if (!m.getName().equals(name) || pt.length != args.length) continue;
            boolean ok = true;
            for (int i = 0; i < pt.length; i++) {
                if (!wrap(pt[i]).isInstance(args[i])) { ok = false; break; }
            }
            if (ok) return m.invoke(target, args);
        }
        throw new NoSuchMethodException(name);
    }

    private static String msg(Throwable t) {
        Throwable c = t;
        while (c.getCause() != null) c = c.getCause();
        String m = c.getMessage();
        return m == null ? c.getClass().getSimpleName() : m;
    }

    static List<String> installed(int cat) {
        List<String> out = new ArrayList<String>();
        try {
            Object r = call(core(), "getInstalledApplications", 0, cat);
            if (r instanceof List) {
                for (Object o : (List<?>) r) {
                    if (o instanceof ApplicationInfo) out.add(((ApplicationInfo) o).packageName);
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "installed() failed: " + msg(t));
        }
        return out;
    }

    private static void ensureUser(int cat) {
        try {
            Object users = call(core(), "getUsers");
            if (users instanceof List) {
                for (Object u : (List<?>) users) {
                    try {
                        Field id = u.getClass().getField("id");
                        if (id.getInt(u) == cat) return;
                    } catch (Exception ignored) { }
                }
            }
        } catch (Throwable ignored) { }
        try { call(core(), "createUser", cat); return; } catch (Throwable ignored) { }
        try {
            Method gm = BlackBoxCore.class.getMethod("getBUserManager");
            Object um = gm.invoke(null);
            call(um, "createUser", cat);
        } catch (Throwable ignored) { }
    }

    private static String resultError(Object r) {
        if (r == null) return null;
        try {
            Field s = r.getClass().getField("success");
            if (!s.getBoolean(r)) {
                try {
                    Field m = r.getClass().getField("msg");
                    Object v = m.get(r);
                    if (v != null) return String.valueOf(v);
                } catch (Exception ignored) { }
                return "Install failed";
            }
        } catch (NoSuchFieldException e) {
            try {
                Method ok = r.getClass().getMethod("isSuccess");
                Object v = ok.invoke(r);
                if (v instanceof Boolean && !((Boolean) v)) return "Install failed";
            } catch (Exception ignored) { }
        } catch (Exception ignored) { }
        return null;
    }

    /** returns null on success, otherwise an error message */
    static String install(String pkg, int cat) {
        try {
            ensureUser(cat);
            String err = resultError(call(core(), "installPackageAsUser", pkg, cat));
            if (err != null) return err;
            return installed(cat).contains(pkg) ? null : "Engine could not clone this app (it may use split APKs)";
        } catch (Throwable t) {
            return msg(t);
        }
    }

    static String installFile(File apk, int cat) {
        try {
            ensureUser(cat);
            String err = resultError(call(core(), "installPackageAsUser", apk, cat));
            return err;
        } catch (Throwable t) {
            return msg(t);
        }
    }

    static boolean launch(String pkg, int cat) {
        try {
            Object r = call(core(), "launchApk", pkg, cat);
            return !(r instanceof Boolean) || (Boolean) r;
        } catch (Throwable t) {
            Log.w(TAG, "launch failed: " + msg(t));
            return false;
        }
    }

    static void remove(String pkg, int cat) {
        try { call(core(), "uninstallPackageAsUser", pkg, cat); return; } catch (Throwable ignored) { }
        try { call(core(), "uninstallPackage", pkg, cat); } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------ split APK merge
    private static void copyZip(String path, ZipOutputStream zos, Set<String> seen, boolean onlyNative) throws IOException {
        ZipFile zf = new ZipFile(path);
        try {
            Enumeration<? extends ZipEntry> en = zf.entries();
            byte[] buf = new byte[65536];
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || seen.contains(n)) continue;
                if (onlyNative && !(n.startsWith("lib/") || n.startsWith("assets/"))) continue;
                seen.add(n);
                zos.putNextEntry(new ZipEntry(n));
                InputStream in = zf.getInputStream(e);
                int r;
                while ((r = in.read(buf)) > 0) zos.write(buf, 0, r);
                in.close();
                zos.closeEntry();
            }
        } finally {
            zf.close();
        }
    }

    static boolean hasSplits(Context ctx, String pkg) {
        try {
            ApplicationInfo ai = ctx.getPackageManager().getApplicationInfo(pkg, 0);
            return ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Builds one APK = base + native libs/assets from every split (the engine only copies the base APK). */
    static File mergeSplits(Context ctx, String pkg) {
        try {
            ApplicationInfo ai = ctx.getPackageManager().getApplicationInfo(pkg, 0);
            if (ai.splitSourceDirs == null || ai.splitSourceDirs.length == 0) return null;
            File out = new File(ctx.getCacheDir(), "merged_" + pkg + ".apk");
            if (out.exists()) out.delete();
            ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out), 1 << 16));
            Set<String> seen = new HashSet<String>();
            copyZip(ai.sourceDir, zos, seen, false);
            for (String sp : ai.splitSourceDirs) copyZip(sp, zos, seen, true);
            zos.close();
            return out;
        } catch (Throwable t) {
            Log.w(TAG, "merge failed: " + msg(t));
            return null;
        }
    }

    /** Clones an installed app; split-APK apps are merged first so their native libraries come along. */
    static String installSmart(Context ctx, String pkg, int cat) {
        if (hasSplits(ctx, pkg)) {
            File merged = mergeSplits(ctx, pkg);
            if (merged != null) {
                String err = installFile(merged, cat);
                if (err == null && installed(cat).contains(pkg)) return null;
            }
        }
        return install(pkg, cat);
    }

    // ------------------------------------------------------------ Google services
    static final String GMS = "com.google.android.gms";
    static final String GSF = "com.google.android.gsf";
    static final String STORE = "com.android.vending";
    static final String[] GOOGLE_PKGS = {GSF, GMS, STORE};
    static String googleLog = "";

    static boolean hasGms(int cat) { return installed(cat).contains(GMS); }

    /** Copies the phone's own Google Play services into this category. Returns null on success. */
    static String installGoogle(Context ctx, int cat) {
        StringBuilder log = new StringBuilder();
        PackageManager pm = ctx.getPackageManager();
        List<String> have = installed(cat);
        for (String p : GOOGLE_PKGS) {
            if (have.contains(p)) { log.append("\u2713 ").append(p).append(" (already there)\n"); continue; }
            try { pm.getPackageInfo(p, 0); } catch (Throwable t) {
                log.append("- ").append(p).append(" (not on this phone)\n");
                continue;
            }
            boolean split = hasSplits(ctx, p);
            String err = installSmart(ctx, p, cat);
            log.append(err == null ? "\u2713 " : "\u2717 ").append(p);
            if (err != null) log.append(": ").append(err);
            else if (split) log.append(" (split APKs merged)");
            log.append('\n');
        }
        googleLog = log.toString();
        return hasGms(cat) ? null : "Google Play services could not be added";
    }
}
