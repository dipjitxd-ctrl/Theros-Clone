package com.theros.cloner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            Prefs.init(c);
            if (Prefs.nativeOn() && Prefs.autostart()) KeepAliveService.start(c);
        } catch (Throwable ignored) { }
    }
}
