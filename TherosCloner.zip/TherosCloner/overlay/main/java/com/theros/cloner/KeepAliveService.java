package com.theros.cloner;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.PixelFormat;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** "Native Unrestricted" mode: foreground service + wake/Wi-Fi locks + process anchors (+ optional 1px overlay). */
public class KeepAliveService extends Service {
    private static final String CH = "keepalive";
    private static final int NID = 7001;

    private PowerManager.WakeLock wl;
    private WifiManager.WifiLock wifi;
    private View overlay;
    private long lastBoost = 0;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<Integer, ServiceConnection> anchors = new HashMap<Integer, ServiceConnection>();

    static void start(Context c) {
        Intent i = new Intent(c, KeepAliveService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, KeepAliveService.class));
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Prefs.init(this);
        createChannel();
        Notification n = notification("Starting\u2026");
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, 0x40000000); // specialUse
        else startForeground(NID, n);
        acquireLocks();
        h.removeCallbacks(tick);
        h.post(tick);
        return START_STICKY;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            try {
                syncAnchors();
                updateOverlay();
                long now = SystemClock.elapsedRealtime();
                if (now - lastBoost > 10 * 60 * 1000L) {
                    lastBoost = now;
                    if (Shell.active() != Shell.Mode.NONE) Boost.applyAsync(KeepAliveService.this, null);
                }
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.notify(NID, notification(statusText()));
            } catch (Throwable ignored) { }
            h.postDelayed(this, 5000);
        }
    };

    private String statusText() {
        Shell.Mode m = Shell.active();
        String layer = m == Shell.Mode.ROOT ? "Root" : (m == Shell.Mode.SHIZUKU ? "Shizuku layer" : "Native");
        return layer + " \u00b7 " + anchors.size() + " clone process(es) protected";
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CH, "Keep-alive", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private Notification notification(String text) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        int icon = getResources().getIdentifier("ic_stat", "drawable", getPackageName());
        if (icon == 0) icon = android.R.drawable.stat_notify_sync;
        b.setSmallIcon(icon)
            .setContentTitle("Theros Cloner is running")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi);
        return b.build();
    }

    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (wl == null) {
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "theros:keepalive");
                wl.setReferenceCounted(false);
            }
            if (!wl.isHeld()) wl.acquire();
        } catch (Throwable ignored) { }
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm != null && wifi == null) {
                wifi = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? 4 : 3, "theros:wifi");
                wifi.setReferenceCounted(false);
            }
            if (wifi != null && !wifi.isHeld()) wifi.acquire();
        } catch (Throwable ignored) { }
    }

    private void syncAnchors() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> l = am.getRunningAppProcesses();
        Set<Integer> live = new HashSet<Integer>();
        String prefix = getPackageName() + ":p";
        if (l != null) {
            for (ActivityManager.RunningAppProcessInfo p : l) {
                if (p.processName != null && p.processName.startsWith(prefix)) {
                    try {
                        int idx = Integer.parseInt(p.processName.substring(prefix.length()));
                        if (idx >= 0 && idx < Anchors.CLASSES.length) live.add(idx);
                    } catch (NumberFormatException ignored) { }
                }
            }
        }
        for (final Integer idx : live) {
            if (anchors.containsKey(idx)) continue;
            ServiceConnection sc = new ServiceConnection() {
                @Override public void onServiceConnected(ComponentName name, IBinder service) { }
                @Override public void onServiceDisconnected(ComponentName name) { }
            };
            try {
                if (bindService(new Intent(this, Anchors.CLASSES[idx]), sc, Context.BIND_AUTO_CREATE | Context.BIND_IMPORTANT)) {
                    anchors.put(idx, sc);
                }
            } catch (Throwable ignored) { }
        }
        Set<Integer> gone = new HashSet<Integer>(anchors.keySet());
        gone.removeAll(live);
        for (Integer idx : gone) {
            try { unbindService(anchors.get(idx)); } catch (Throwable ignored) { }
            anchors.remove(idx);
        }
    }

    private void updateOverlay() {
        boolean want = Prefs.overlay() && Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this);
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (want && overlay == null) {
            try {
                View v = new View(this);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1,
                    Build.VERSION.SDK_INT >= 26 ? 2038 : 2002,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.START;
                wm.addView(v, lp);
                overlay = v;
            } catch (Throwable ignored) { }
        } else if (!want && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) { }
            overlay = null;
        }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        for (ServiceConnection sc : anchors.values()) {
            try { unbindService(sc); } catch (Throwable ignored) { }
        }
        anchors.clear();
        if (overlay != null) {
            try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(overlay); } catch (Throwable ignored) { }
            overlay = null;
        }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Throwable ignored) { }
        super.onDestroy();
    }
}
