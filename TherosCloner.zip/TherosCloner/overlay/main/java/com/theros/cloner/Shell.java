package com.theros.cloner;

import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Runs commands with root (su) or Shizuku (adb-level) access. */
final class Shell {
    enum Mode { NONE, ROOT, SHIZUKU }

    static final class Res {
        int code;
        String out = "";
    }

    private static volatile boolean rootOk = false;

    static boolean rootAvailable() { return rootOk; }

    static synchronized boolean checkRoot() {
        try {
            Process p = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
            Res r = exec(p, 10);
            rootOk = r.code == 0 && r.out.contains("uid=0");
        } catch (Throwable t) {
            rootOk = false;
        }
        return rootOk;
    }

    static boolean shizukuReady() {
        try {
            return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static Mode active() {
        if (Prefs.useRoot() && rootOk) return Mode.ROOT;
        if (Prefs.shizuku() && shizukuReady()) return Mode.SHIZUKU;
        return Mode.NONE;
    }

    static Res run(String cmd) {
        Mode m = active();
        try {
            if (m == Mode.ROOT) {
                return exec(new ProcessBuilder("su", "-c", cmd + " 2>&1").redirectErrorStream(true).start(), 20);
            }
            if (m == Mode.SHIZUKU) {
                Method nm = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
                nm.setAccessible(true);
                Process p = (Process) nm.invoke(null, new Object[]{new String[]{"sh", "-c", cmd + " 2>&1"}, null, null});
                return exec(p, 20);
            }
        } catch (Throwable t) {
            Res r = new Res();
            r.code = -2;
            r.out = String.valueOf(t);
            return r;
        }
        Res r = new Res();
        r.code = -3;
        r.out = "no privileged access";
        return r;
    }

    private static Res exec(final Process p, final int timeoutSec) {
        final StringBuilder sb = new StringBuilder();
        Thread rd = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                    String l;
                    while ((l = br.readLine()) != null) {
                        if (sb.length() < 4000) sb.append(l).append('\n');
                    }
                } catch (Throwable ignored) { }
            }
        });
        rd.start();
        final boolean[] done = {false};
        Thread wd = new Thread(new Runnable() {
            @Override public void run() {
                try { Thread.sleep(timeoutSec * 1000L); } catch (InterruptedException e) { return; }
                if (!done[0]) p.destroy();
            }
        });
        wd.start();
        int code = -1;
        try { code = p.waitFor(); } catch (InterruptedException ignored) { }
        done[0] = true;
        wd.interrupt();
        try { rd.join(500); } catch (InterruptedException ignored) { }
        Res r = new Res();
        r.code = code;
        r.out = sb.toString().trim();
        return r;
    }
}
