package com.theros.cloner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQ_APK = 21;
    private static final int REQ_SHIZUKU = 31;
    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";

    private Ui.Pal P;
    private LinearLayout appsBox;
    private final TextView[] chips = new TextView[Virtual.CATS];
    private TextView catTitle, nativeSub, shzSub, rootSub, battBtn, dataBtn, ovlBtn, shzBtn, gmsSub, gmsBtn;
    private Switch swNative, swShz, swRoot, swGms;
    private int cat = 0;
    private int shzState = 0; // 0 missing, 1 not running, 2 needs permission, 3 ready
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() { refreshStatus(); h.postDelayed(this, 2000); }
    };
    private Shizuku.OnRequestPermissionResultListener permListener;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.init(this);
        P = Ui.pal(this);
        if (Build.VERSION.SDK_INT >= 23 && !Ui.dark(this)) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0));
        }
        buildUi();
        select(0);

        if (Build.VERSION.SDK_INT >= 33
            && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        if (Prefs.nativeOn()) KeepAliveService.start(this);

        permListener = new Shizuku.OnRequestPermissionResultListener() {
            @Override public void onRequestPermissionResult(int requestCode, int grantResult) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) Boost.applyAsync(MainActivity.this, null);
                runOnUiThread(new Runnable() { @Override public void run() { refreshStatus(); } });
            }
        };
        try { Shizuku.addRequestPermissionResultListener(permListener); } catch (Throwable ignored) { }

        new Thread(new Runnable() {
            @Override public void run() {
                Shell.checkRoot();
                runOnUiThread(new Runnable() { @Override public void run() { refreshStatus(); } });
                if (Shell.active() != Shell.Mode.NONE) Boost.apply(MainActivity.this);
            }
        }).start();
    }

    @Override protected void onResume() { super.onResume(); h.post(ticker); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(ticker); }

    @Override
    protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener); } catch (Throwable ignored) { }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ UI

    private int dp(float v) { return Ui.dp(this, v); }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(P.bg);
        sv.setFillViewport(true);
        sv.setFitsSystemWindows(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(Ui.tv(this, "Theros Cloner", 26, P.text, true));
        root.addView(Ui.tv(this, "Up to 5 isolated copies of any app \u00b7 split-screen & floating ready", 13, P.sub, false),
            Ui.lp(-1, -2, 0, dp(2), 0, dp(16)));

        // ---------- categories ----------
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Virtual.CATS; i++) {
            final int idx = i;
            TextView c = Ui.tv(this, Prefs.catName(i), 14, P.text, true);
            c.setPadding(dp(16), dp(9), dp(16), dp(9));
            c.setGravity(Gravity.CENTER);
            c.setClickable(true);
            c.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { select(idx); } });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) { rename(idx); return true; }
            });
            chips[i] = c;
            chipRow.addView(c, Ui.lp(-2, -2, 0, 0, dp(8), 0));
        }
        hs.addView(chipRow);
        root.addView(hs);

        LinearLayout catCard = Ui.card(this, P);
        root.addView(catCard, Ui.lp(-1, -2, 0, dp(12), 0, 0));
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        catTitle = Ui.tv(this, "", 17, P.text, true);
        head.addView(catTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(Ui.button(this, "+ Add app", P.primary, P.onPrimary, new View.OnClickListener() {
            @Override public void onClick(View v) { showPicker(); }
        }));
        catCard.addView(head);
        appsBox = new LinearLayout(this);
        appsBox.setOrientation(LinearLayout.VERTICAL);
        catCard.addView(appsBox, Ui.lp(-1, -2, 0, dp(8), 0, 0));
        catCard.addView(Ui.tv(this, "Tip: long-press a category to rename it.", 12, P.sub, false), Ui.lp(-1, -2, 0, dp(6), 0, 0));

        // ---------- Google Play services ----------
        LinearLayout gcard = Ui.card(this, P);
        root.addView(gcard, Ui.lp(-1, -2, 0, dp(10), 0, 0));
        swGms = new Switch(this);
        gmsSub = Ui.tv(this, "", 12, P.sub, false);
        gcard.addView(switchRow("Google Play services", gmsSub, swGms));
        swGms.setChecked(Prefs.autoGms());
        swGms.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) { Prefs.setAutoGms(on); }
        });
        gcard.addView(Ui.tv(this, "Switch = add automatically the first time you clone an app into a category.", 11, P.sub, false),
            Ui.lp(-1, -2, 0, dp(4), 0, 0));
        gmsBtn = Ui.button(this, "Enable for this category", P.primary, P.onPrimary, new View.OnClickListener() {
            @Override public void onClick(View v) { enableGoogle(); }
        });
        gcard.addView(gmsBtn, Ui.lp(-1, -2, 0, dp(10), 0, 0));

        // ---------- background engine ----------
        root.addView(Ui.tv(this, "Background engine", 15, P.primary, true), Ui.lp(-1, -2, dp(4), dp(22), 0, dp(8)));

        // 1. Native
        LinearLayout nat = Ui.card(this, P);
        root.addView(nat);
        swNative = new Switch(this);
        nativeSub = Ui.tv(this, "", 12, P.sub, false);
        nat.addView(switchRow("Native Unrestricted", nativeSub, swNative));
        swNative.setChecked(Prefs.nativeOn());
        swNative.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                Prefs.setNative(on);
                if (on) KeepAliveService.start(MainActivity.this); else KeepAliveService.stop(MainActivity.this);
                refreshStatus();
            }
        });
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        battBtn = Ui.button(this, "Battery", P.chip, P.text, new View.OnClickListener() {
            @Override public void onClick(View v) { openBattery(); }
        });
        dataBtn = Ui.button(this, "Data", P.chip, P.text, new View.OnClickListener() {
            @Override public void onClick(View v) { openDataSaver(); }
        });
        ovlBtn = Ui.button(this, "Overlay", P.chip, P.text, new View.OnClickListener() {
            @Override public void onClick(View v) { toggleOverlay(); }
        });
        row.addView(battBtn, Ui.lp(0, -2, 0, 0, dp(6), 0));
        ((LinearLayout.LayoutParams) battBtn.getLayoutParams()).weight = 1f;
        row.addView(dataBtn, Ui.lp(0, -2, 0, 0, dp(6), 0));
        ((LinearLayout.LayoutParams) dataBtn.getLayoutParams()).weight = 1f;
        row.addView(ovlBtn, Ui.lp(0, -2, 0, 0, 0, 0));
        ((LinearLayout.LayoutParams) ovlBtn.getLayoutParams()).weight = 1f;
        nat.addView(row, Ui.lp(-1, -2, 0, dp(10), 0, 0));

        // 2. Shizuku layer
        LinearLayout shz = Ui.card(this, P);
        root.addView(shz, Ui.lp(-1, -2, 0, dp(10), 0, 0));
        swShz = new Switch(this);
        shzSub = Ui.tv(this, "", 12, P.sub, false);
        shz.addView(switchRow("Shizuku Layer", shzSub, swShz));
        swShz.setChecked(Prefs.shizuku());
        swShz.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                Prefs.setShizuku(on);
                if (on && Shell.shizukuReady()) Boost.applyAsync(MainActivity.this, null);
                refreshStatus();
            }
        });
        LinearLayout srow = new LinearLayout(this);
        srow.setOrientation(LinearLayout.HORIZONTAL);
        shzBtn = Ui.button(this, "Set up", P.chip, P.text, new View.OnClickListener() {
            @Override public void onClick(View v) { shizukuAction(); }
        });
        TextView logBtn = Ui.button(this, "View log", P.chip, P.text, new View.OnClickListener() {
            @Override public void onClick(View v) { showLog(Prefs.lastLog()); }
        });
        srow.addView(shzBtn, Ui.lp(0, -2, 0, 0, dp(6), 0));
        ((LinearLayout.LayoutParams) shzBtn.getLayoutParams()).weight = 1f;
        srow.addView(logBtn, Ui.lp(0, -2, 0, 0, 0, 0));
        ((LinearLayout.LayoutParams) logBtn.getLayoutParams()).weight = 1f;
        shz.addView(srow, Ui.lp(-1, -2, 0, dp(10), 0, 0));

        // 3. Root
        LinearLayout rt = Ui.card(this, P);
        root.addView(rt, Ui.lp(-1, -2, 0, dp(10), 0, 0));
        swRoot = new Switch(this);
        rootSub = Ui.tv(this, "Checking\u2026", 12, P.sub, false);
        rt.addView(switchRow("Root access", rootSub, swRoot));
        swRoot.setChecked(Prefs.useRoot());
        swRoot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                Prefs.setUseRoot(on);
                if (on && Shell.rootAvailable()) Boost.applyAsync(MainActivity.this, null);
                refreshStatus();
            }
        });

        // ---------- windows ----------
        LinearLayout win = Ui.card(this, P);
        root.addView(win, Ui.lp(-1, -2, 0, dp(10), 0, 0));
        win.addView(Ui.tv(this, "Split-screen & floating windows", 15, P.text, true));
        win.addView(Ui.tv(this,
            "Every clone window is fully resizable. Open the Recents screen, tap the app icon of a clone and choose "
                + "Split screen or Pop-up / Floating window (wording depends on your phone). "
                + "Keeping a clone visible in a floating window is the most reliable way to keep a game connected.",
            12, P.sub, false), Ui.lp(-1, -2, 0, dp(4), 0, 0));

        setContentView(sv);
    }

    private View switchRow(String title, TextView sub, Switch sw) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(Ui.tv(this, title, 16, P.text, true));
        t.addView(sub, Ui.lp(-1, -2, 0, dp(2), 0, 0));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(sw);
        return r;
    }

    // ------------------------------------------------------------------ status

    private boolean pkgInstalled(String pkg) {
        try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Throwable t) { return false; }
    }

    private void refreshStatus() {
        // native
        boolean ign = Build.VERSION.SDK_INT < 23
            || ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
        nativeSub.setText(Prefs.nativeOn()
            ? "Running \u00b7 wake lock \u00b7 Wi-Fi lock \u00b7 process anchors"
            : "Off \u2014 clones can be paused by Android");
        battBtn.setText(ign ? "Battery \u2713" : "Battery: allow");
        Ui.skin(this, battBtn, ign ? P.chip : P.primary, ign ? P.ok : P.onPrimary, 12);

        int rb = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getRestrictBackgroundStatus();
        boolean dataOk = rb != ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED;
        dataBtn.setText(dataOk ? "Data \u2713" : "Data: allow");
        Ui.skin(this, dataBtn, dataOk ? P.chip : P.primary, dataOk ? P.ok : P.onPrimary, 12);

        boolean ovl = Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this);
        boolean ovlOn = ovl && Prefs.overlay();
        ovlBtn.setText(ovlOn ? "Overlay \u2713" : "Overlay");
        Ui.skin(this, ovlBtn, P.chip, ovlOn ? P.ok : P.text, 12);

        // shizuku
        String s;
        if (!pkgInstalled(SHIZUKU_PKG)) { shzState = 0; s = "Shizuku app not installed"; }
        else {
            shzState = 1;
            s = "Shizuku isn't running \u2014 start it in the Shizuku app";
            try {
                if (Shizuku.pingBinder()) {
                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { shzState = 3; s = "Connected \u2713 (adb-level access)"; }
                    else { shzState = 2; s = "Needs permission \u2014 tap Grant"; }
                }
            } catch (Throwable t) { shzState = 1; }
        }
        shzSub.setText(Prefs.shizuku() ? s : "Off \u00b7 " + s);
        shzBtn.setText(shzState == 0 ? "Get Shizuku" : shzState == 1 ? "Open Shizuku" : shzState == 2 ? "Grant" : "Apply now");

        // root
        boolean rootOk = Shell.rootAvailable();
        rootSub.setText(rootOk ? "Root detected \u2713 \u2014 everything is unlocked" : "No root detected");
        swRoot.setEnabled(rootOk);
    }

    private void shizukuAction() {
        try {
            if (shzState == 0) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")));
            } else if (shzState == 1) {
                Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
                if (i != null) startActivity(i);
            } else if (shzState == 2) {
                Shizuku.requestPermission(REQ_SHIZUKU);
            } else {
                Toast.makeText(this, "Applying\u2026", Toast.LENGTH_SHORT).show();
                Boost.applyAsync(this, new Boost.Done() {
                    @Override public void done(String log) { showLog(log); }
                });
            }
        } catch (Throwable t) {
            Toast.makeText(this, "Couldn't open: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showLog(String log) {
        TextView t = Ui.tv(this, log, 12, P.text, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setPadding(dp(18), dp(12), dp(18), dp(12));
        ScrollView s = new ScrollView(this);
        s.addView(t);
        new AlertDialog.Builder(this).setTitle("Privileged layer log").setView(s).setPositiveButton("OK", null).show();
    }

    private void openBattery() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Throwable t) {
            try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Throwable ignored) { }
        }
    }

    private void openDataSaver() {
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BACKGROUND_DATA_RESTRICTIONS_SETTINGS, Uri.parse("package:" + getPackageName())));
        } catch (Throwable t) {
            Toast.makeText(this, "Data Saver is already off or not supported", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (Throwable ignored) { }
            return;
        }
        Prefs.setOverlay(!Prefs.overlay());
        Toast.makeText(this, Prefs.overlay() ? "Keep-visible overlay on" : "Keep-visible overlay off", Toast.LENGTH_SHORT).show();
        refreshStatus();
    }

    // ------------------------------------------------------------------ categories & apps

    private void select(int i) {
        cat = i;
        for (int k = 0; k < chips.length; k++) {
            boolean sel = k == cat;
            chips[k].setText(Prefs.catName(k));
            Ui.skin(this, chips[k], sel ? P.primary : P.chip, sel ? P.onPrimary : P.text, 20);
        }
        catTitle.setText(Prefs.catName(cat));
        renderApps();
    }

    private void rename(final int idx) {
        final EditText e = new EditText(this);
        e.setText(Prefs.catName(idx));
        e.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Rename category").setView(e)
            .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface d, int w) {
                    String n = e.getText().toString().trim();
                    if (n.length() > 0) Prefs.setCatName(idx, n.length() > 18 ? n.substring(0, 18) : n);
                    select(cat);
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private void renderApps() {
        final int c = cat;
        new Thread(new Runnable() {
            @Override public void run() {
                final List<String> l = Virtual.installed(c);
                runOnUiThread(new Runnable() {
                    @Override public void run() { if (c == cat) fillApps(l); }
                });
            }
        }).start();
    }

    private void fillApps(List<String> list) {
        boolean has = list.contains(Virtual.GMS);
        gmsSub.setText(has ? "Installed in " + Prefs.catName(cat) + " \u2713" : "Not installed in " + Prefs.catName(cat));
        gmsBtn.setVisibility(has ? View.GONE : View.VISIBLE);
        List<String> rows = new ArrayList<String>();
        for (String p : list) {
            if (!p.equals(Virtual.GMS) && !p.equals(Virtual.GSF)) rows.add(p);
        }
        appsBox.removeAllViews();
        if (rows.isEmpty()) {
            TextView t = Ui.tv(this, "No apps in this category yet.\nTap \u201c+ Add app\u201d to clone one here.", 13, P.sub, false);
            t.setPadding(0, dp(10), 0, dp(6));
            appsBox.addView(t);
            return;
        }
        for (final String pkg : rows) appsBox.addView(appRow(pkg), Ui.lp(-1, -2, 0, dp(8), 0, 0));
    }

    private void enableGoogle() {
        final int c = cat;
        final AlertDialog wait = new AlertDialog.Builder(this).setTitle("Google Play services")
            .setMessage("Adding Google services to " + Prefs.catName(c) + "\u2026 this can take up to a minute.")
            .setCancelable(false).show();
        new Thread(new Runnable() {
            @Override public void run() {
                final String err = Virtual.installGoogle(MainActivity.this, c);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        wait.dismiss();
                        Toast.makeText(MainActivity.this,
                            err == null ? "Google services ready" : "Couldn't add Google services: " + err,
                            Toast.LENGTH_LONG).show();
                        renderApps();
                    }
                });
            }
        }).start();
    }

    private View appRow(final String pkg) {
        PackageManager pm = getPackageManager();
        String label = pkg;
        Drawable icon = null;
        try {
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            label = String.valueOf(pm.getApplicationLabel(ai));
            icon = pm.getApplicationIcon(ai);
        } catch (Throwable ignored) { }
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(8), dp(8), dp(8));
        r.setBackground(Ui.rect(this, P.chip, 14));
        ImageView iv = new ImageView(this);
        if (icon != null) iv.setImageDrawable(icon);
        r.addView(iv, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(12), 0, dp(8), 0);
        t.addView(Ui.tv(this, label, 15, P.text, true));
        t.addView(Ui.tv(this, pkg, 11, P.sub, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(Ui.button(this, "Open", P.primary, P.onPrimary, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!Virtual.launch(pkg, cat)) Toast.makeText(MainActivity.this, "Couldn't start this clone", Toast.LENGTH_SHORT).show();
            }
        }));
        TextView x = Ui.button(this, "\u2715", P.chip, P.bad, new View.OnClickListener() {
            @Override public void onClick(View v) { confirmRemove(pkg); }
        });
        r.addView(x, Ui.lp(-2, -2, dp(6), 0, 0, 0));
        return r;
    }

    private void confirmRemove(final String pkg) {
        final int c = cat;
        new AlertDialog.Builder(this).setTitle("Remove clone?")
            .setMessage("This deletes the clone and its data from " + Prefs.catName(c) + ". The original app is not touched.")
            .setPositiveButton("Remove", new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface d, int w) {
                    new Thread(new Runnable() {
                        @Override public void run() {
                            Virtual.remove(pkg, c);
                            runOnUiThread(new Runnable() { @Override public void run() { renderApps(); } });
                        }
                    }).start();
                }
            }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ picker / install

    private static final class Item {
        String label, pkg;
        ResolveInfo ri;
    }

    private void showPicker() {
        final int c = cat;
        Toast.makeText(this, "Loading apps\u2026", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override public void run() {
                PackageManager pm = getPackageManager();
                Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> l = pm.queryIntentActivities(i, 0);
                List<String> have = Virtual.installed(c);
                final List<Item> items = new ArrayList<Item>();
                for (ResolveInfo ri : l) {
                    String p = ri.activityInfo.packageName;
                    if (p.equals(getPackageName()) || have.contains(p)) continue;
                    Item it = new Item();
                    it.pkg = p;
                    it.label = String.valueOf(ri.loadLabel(pm));
                    it.ri = ri;
                    items.add(it);
                }
                Collections.sort(items, new Comparator<Item>() {
                    @Override public int compare(Item a, Item b) { return a.label.compareToIgnoreCase(b.label); }
                });
                runOnUiThread(new Runnable() { @Override public void run() { openPicker(items, c); } });
            }
        }).start();
    }

    private void openPicker(final List<Item> all, final int c) {
        final List<Item> shown = new ArrayList<Item>(all);
        final PackageManager pm = getPackageManager();
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int p) { return shown.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View cv, ViewGroup parent) {
                Item it = shown.get(p);
                LinearLayout r = new LinearLayout(MainActivity.this);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(dp(16), dp(8), dp(16), dp(8));
                ImageView iv = new ImageView(MainActivity.this);
                iv.setImageDrawable(it.ri.loadIcon(pm));
                r.addView(iv, new LinearLayout.LayoutParams(dp(38), dp(38)));
                LinearLayout t = new LinearLayout(MainActivity.this);
                t.setOrientation(LinearLayout.VERTICAL);
                t.setPadding(dp(12), 0, 0, 0);
                t.addView(Ui.tv(MainActivity.this, it.label, 15, P.text, true));
                t.addView(Ui.tv(MainActivity.this, it.pkg, 11, P.sub, false));
                r.addView(t);
                return r;
            }
        };

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(P.card);
        final EditText search = new EditText(this);
        search.setHint("Search apps");
        search.setSingleLine(true);
        search.setTextColor(P.text);
        search.setHintTextColor(P.sub);
        search.setPadding(dp(18), dp(12), dp(18), dp(12));
        box.addView(search);
        box.addView(Ui.button(this, "Clone from an APK file instead", P.chip, P.primary, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                try { startActivityForResult(i, REQ_APK); } catch (ActivityNotFoundException ignored) { }
            }
        }), Ui.lp(-1, -2, dp(14), 0, dp(14), dp(6)));
        ListView lv = new ListView(this);
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(420)));

        final AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Add to " + Prefs.catName(c)).setView(box)
            .setNegativeButton("Close", null).create();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable s) {
                String q = s.toString().trim().toLowerCase();
                shown.clear();
                for (Item it : all) {
                    if (q.length() == 0 || it.label.toLowerCase().contains(q) || it.pkg.toLowerCase().contains(q)) shown.add(it);
                }
                ad.notifyDataSetChanged();
            }
        });
        lv.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                Item it = shown.get(pos);
                dlg.dismiss();
                cloneApp(it.pkg, it.label, c);
            }
        });
        dlg.show();
    }

    private void cloneApp(final String pkg, String label, final int c) {
        final AlertDialog wait = new AlertDialog.Builder(this).setTitle("Cloning " + label)
            .setMessage("Please wait\u2026 this can take a few seconds.").setCancelable(false).show();
        new Thread(new Runnable() {
            @Override public void run() {
                String gerr = null;
                if (Prefs.autoGms() && !Virtual.hasGms(c)) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { wait.setMessage("Setting up Google services (first time only)\u2026"); }
                    });
                    gerr = Virtual.installGoogle(MainActivity.this, c);
                    runOnUiThread(new Runnable() {
                        @Override public void run() { wait.setMessage("Cloning the app\u2026"); }
                    });
                }
                final String err = Virtual.install(pkg, c);
                final String gmsMsg = gerr;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        wait.dismiss();
                        if (gmsMsg != null) Toast.makeText(MainActivity.this, "Google services not added: " + gmsMsg, Toast.LENGTH_LONG).show();
                        if (err != null) Toast.makeText(MainActivity.this, "Clone failed: " + err, Toast.LENGTH_LONG).show();
                        renderApps();
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onActivityResult(int req, int res, final Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_APK || res != RESULT_OK || data == null || data.getData() == null) return;
        final int c = cat;
        final Uri u = data.getData();
        final AlertDialog wait = new AlertDialog.Builder(this).setTitle("Cloning from APK")
            .setMessage("Please wait\u2026").setCancelable(false).show();
        new Thread(new Runnable() {
            @Override public void run() {
                String err;
                try {
                    File f = new File(getCacheDir(), "clone.apk");
                    InputStream in = getContentResolver().openInputStream(u);
                    FileOutputStream out = new FileOutputStream(f);
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    out.close();
                    in.close();
                    if (Prefs.autoGms() && !Virtual.hasGms(c)) Virtual.installGoogle(MainActivity.this, c);
                    err = Virtual.installFile(f, c);
                } catch (Throwable t) {
                    err = String.valueOf(t.getMessage());
                }
                final String e2 = err;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        wait.dismiss();
                        if (e2 != null) Toast.makeText(MainActivity.this, "Clone failed: " + e2, Toast.LENGTH_LONG).show();
                        renderApps();
                    }
                });
            }
        }).start();
    }
}
