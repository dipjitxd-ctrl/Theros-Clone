package com.theros.cloner;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private static SharedPreferences sp;

    static void init(Context c) {
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("theros", Context.MODE_PRIVATE);
    }

    static boolean nativeOn() { return sp.getBoolean("native", true); }
    static void setNative(boolean v) { sp.edit().putBoolean("native", v).apply(); }

    static boolean shizuku() { return sp.getBoolean("shizuku", false); }
    static void setShizuku(boolean v) { sp.edit().putBoolean("shizuku", v).apply(); }

    static boolean useRoot() { return sp.getBoolean("useRoot", true); }
    static void setUseRoot(boolean v) { sp.edit().putBoolean("useRoot", v).apply(); }

    static boolean autoGms() { return sp.getBoolean("autoGms", true); }
    static void setAutoGms(boolean v) { sp.edit().putBoolean("autoGms", v).apply(); }

    static boolean overlay() { return sp.getBoolean("overlay", false); }
    static void setOverlay(boolean v) { sp.edit().putBoolean("overlay", v).apply(); }

    static boolean autostart() { return sp.getBoolean("autostart", true); }
    static void setAutostart(boolean v) { sp.edit().putBoolean("autostart", v).apply(); }

    static String catName(int i) { return sp.getString("cat" + i, "Category " + (i + 1)); }
    static void setCatName(int i, String n) { sp.edit().putString("cat" + i, n).apply(); }

    static String lastLog() { return sp.getString("log", "Nothing applied yet."); }
    static void setLastLog(String s) { sp.edit().putString("log", s).apply(); }
}
