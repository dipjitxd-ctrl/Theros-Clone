package com.theros.cloner;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

/**
 * Tiny services that live inside the virtual-app processes (:p0 .. :p9).
 * The keep-alive service binds to them so Android treats those processes as important
 * and does not park / freeze them when the cloned app goes to the background.
 */
public final class Anchors {
    private Anchors() { }

    public static abstract class Base extends Service {
        private final IBinder binder = new Binder();
        @Override public IBinder onBind(Intent intent) { return binder; }
        @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    }

    public static class P0 extends Base { }
    public static class P1 extends Base { }
    public static class P2 extends Base { }
    public static class P3 extends Base { }
    public static class P4 extends Base { }
    public static class P5 extends Base { }
    public static class P6 extends Base { }
    public static class P7 extends Base { }
    public static class P8 extends Base { }
    public static class P9 extends Base { }

    static final Class<?>[] CLASSES = new Class<?>[]{
        P0.class, P1.class, P2.class, P3.class, P4.class, P5.class, P6.class, P7.class, P8.class, P9.class
    };
}
