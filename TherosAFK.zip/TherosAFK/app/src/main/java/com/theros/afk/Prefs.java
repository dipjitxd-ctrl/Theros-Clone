package com.theros.afk;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private static SharedPreferences sp;

    static void init(Context c) {
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("afk", Context.MODE_PRIVATE);
    }

    static String target() { return sp.getString("target", ""); }
    static void setTarget(String p) { sp.edit().putString("target", p).apply(); }

    static boolean screenOff() { return sp.getBoolean("screenOff", true); }
    static void setScreenOff(boolean v) { sp.edit().putBoolean("screenOff", v).apply(); }

    static boolean antiAfk() { return sp.getBoolean("antiAfk", true); }
    static void setAntiAfk(boolean v) { sp.edit().putBoolean("antiAfk", v).apply(); }

    static int interval() { return sp.getInt("interval", 8); }
    static void setInterval(int m) { sp.edit().putInt("interval", m).apply(); }

    static boolean active() { return sp.getBoolean("active", false); }
    static void setActive(boolean v) { sp.edit().putBoolean("active", v).apply(); }

    // original system values, so they can always be restored
    static boolean hasSaved() { return !sp.getString("savedTimeout", "").isEmpty(); }
    static String savedTimeout() { return sp.getString("savedTimeout", ""); }
    static String savedStayOn() { return sp.getString("savedStayOn", ""); }
    static void setSaved(String timeout, String stayOn) {
        sp.edit().putString("savedTimeout", timeout).putString("savedStayOn", stayOn).apply();
    }
    static void clearSaved() { sp.edit().remove("savedTimeout").remove("savedStayOn").apply(); }
}
