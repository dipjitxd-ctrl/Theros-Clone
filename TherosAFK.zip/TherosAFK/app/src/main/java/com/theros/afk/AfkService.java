package com.theros.afk;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Keeps the chosen game running while the display is off.
 * With Shizuku/root: turns the display panel off ("cmd display power-off 0") while the phone stays awake,
 * so the foreground app keeps running exactly like it does with the screen on.
 * Without: shows a black, dimmest-brightness overlay instead.
 */
public class AfkService extends Service {
    static final String A_START = "com.theros.afk.START";
    static final String A_STOP = "com.theros.afk.STOP";
    static final String A_OFF = "com.theros.afk.OFF";
    static final String A_ON = "com.theros.afk.ON";

    private static final String CH = "afk";
    private static final int NID = 8801;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private PowerManager.WakeLock wl;
    private WifiManager.WifiLock wifi;
    private View dim;
    private volatile boolean running = false;
    private volatile boolean panelOff = false;

    static void send(Context c, String action) {
        Intent i = new Intent(c, AfkService.class).setAction(action);
        if (A_START.equals(action) && Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    /** Puts the phone's own screen-timeout settings back (also used after a crash). */
    static void restoreSettings() {
        if (!Prefs.hasSaved() || Shell.active() == Shell.Mode.NONE) return;
        String t = Prefs.savedTimeout();
        String s = Prefs.savedStayOn();
        if (t.matches("\\d+")) Shell.run("settings put system screen_off_timeout " + t);
        if (s.matches("\\d+")) Shell.run("settings put global stay_on_while_plugged_in " + s);
        Prefs.clearSaved();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Prefs.init(this);
        String a = intent == null ? "" : String.valueOf(intent.getAction());
        if (A_START.equals(a)) {
            startFg("Starting\u2026");
            if (!running) {
                running = true;
                Prefs.setActive(true);
                acquireLocks();
                io.execute(this::begin);
            }
        } else if (A_OFF.equals(a)) {
            io.execute(() -> setPanel(true));
        } else if (A_ON.equals(a)) {
            io.execute(() -> setPanel(false));
        } else if (A_STOP.equals(a)) {
            io.execute(this::end);
        } else {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------------ session

    private void begin() {
        Shell.Mode m = Shell.active();
        String target = Prefs.target();
        if (m != Shell.Mode.NONE) {
            Boost.apply(this, getPackageName(), target);
            keepSystemAwake();
        }
        note("Waiting for the game to load\u2026");
        try { Thread.sleep(10000); } catch (InterruptedException ignored) { }
        if (!running) return;
        if (Prefs.screenOff()) {
            if (m != Shell.Mode.NONE) setPanel(true);
            else h.post(this::showDim);
        } else {
            note("Running \u00b7 screen stays on");
        }
        if (Prefs.antiAfk() && m != Shell.Mode.NONE) scheduleNudge();
    }

    private void end() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (panelOff) Shell.run("cmd display power-on 0");
        panelOff = false;
        restoreSettings();
        Prefs.setActive(false);
        h.post(() -> {
            removeDim();
            releaseLocks();
            stopForeground(true);
            stopSelf();
        });
    }

    private void keepSystemAwake() {
        if (!Prefs.hasSaved()) {
            String t = Shell.out("settings get system screen_off_timeout");
            String s = Shell.out("settings get global stay_on_while_plugged_in");
            if (t.matches("\\d+")) Prefs.setSaved(t, s.matches("\\d+") ? s : "0");
        }
        Shell.run("settings put system screen_off_timeout 2147483647");
        Shell.run("settings put global stay_on_while_plugged_in 7");
    }

    private void setPanel(boolean off) {
        if (Shell.active() == Shell.Mode.NONE) {
            h.post(() -> { if (off) showDim(); else removeDim(); });
            return;
        }
        Shell.run(off ? "cmd display power-off 0" : "cmd display power-on 0");
        panelOff = off;
        note(off ? "Running \u00b7 screen is off" : "Running \u00b7 screen is on");
    }

    // ------------------------------------------------------------------ anti-AFK

    private final Runnable nudge = new Runnable() {
        @Override public void run() {
            if (!running) return;
            io.execute(AfkService.this::doNudge);
            h.postDelayed(this, Math.max(1, Prefs.interval()) * 60000L);
        }
    };

    private void scheduleNudge() {
        h.postDelayed(nudge, Math.max(1, Prefs.interval()) * 60000L);
    }

    @SuppressWarnings("deprecation")
    private void doNudge() {
        try {
            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            int x1 = (int) (dm.widthPixels * 0.70f);
            int x2 = (int) (dm.widthPixels * 0.75f);
            int y = dm.heightPixels / 2;
            Shell.run("input swipe " + x1 + " " + y + " " + x2 + " " + y + " 90");
            Thread.sleep(700);
            Shell.run("input swipe " + x2 + " " + y + " " + x1 + " " + y + " 90");
            if (panelOff) {
                Thread.sleep(1500);
                Shell.run("cmd display power-off 0"); // a touch can wake the panel; switch it off again
            }
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ fallback black screen

    private void showDim() {
        if (dim != null) return;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            note("Allow \u201cdisplay over other apps\u201d to use black-screen mode");
            return;
        }
        try {
            View v = new View(this);
            v.setBackgroundColor(Color.BLACK);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= 26 ? 2038 : 2002,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.OPAQUE);
            lp.screenBrightness = 0.01f;
            ((WindowManager) getSystemService(WINDOW_SERVICE)).addView(v, lp);
            dim = v;
            note("Running \u00b7 black-screen mode (screen is on but dark)");
        } catch (Throwable t) {
            note("Couldn't show the black screen");
        }
    }

    private void removeDim() {
        if (dim == null) return;
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(dim); } catch (Throwable ignored) { }
        dim = null;
    }

    // ------------------------------------------------------------------ locks & notification

    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "theros:afk");
            wl.setReferenceCounted(false);
            wl.acquire();
        } catch (Throwable ignored) { }
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm != null) {
                wifi = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? 4 : 3, "theros:afkwifi");
                wifi.setReferenceCounted(false);
                wifi.acquire();
            }
        } catch (Throwable ignored) { }
    }

    private void releaseLocks() {
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Throwable ignored) { }
    }

    private PendingIntent act(String action, int code) {
        Intent i = new Intent(this, AfkService.class).setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNote(String text) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CH, "AFK session", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        int icon = getResources().getIdentifier("ic_stat", "drawable", getPackageName());
        if (icon == 0) icon = android.R.drawable.stat_notify_sync;
        b.setSmallIcon(icon)
            .setContentTitle("AFK Keeper is running")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Screen off", act(A_OFF, 1))
            .addAction(0, "Screen on", act(A_ON, 2))
            .addAction(0, "Stop", act(A_STOP, 3));
        return b.build();
    }

    private void startFg(String text) {
        Notification n = buildNote(text);
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, 0x40000000); // specialUse
        else startForeground(NID, n);
    }

    private void note(String text) {
        try {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NID, buildNote(text));
        } catch (Throwable ignored) { }
    }

    @Override
    public void onDestroy() {
        removeDim();
        releaseLocks();
        io.shutdown();
        super.onDestroy();
    }
}
