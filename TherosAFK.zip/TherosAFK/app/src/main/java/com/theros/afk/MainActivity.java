package com.theros.afk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final int[] INTERVALS = {5, 8, 12, 15};

    private Ui.Pal P;
    private TextView accSub, accBtn, tgtName, startBtn, modeNote;
    private ImageView tgtIcon;
    private Switch swOff, swAfk;
    private final TextView[] ivChips = new TextView[INTERVALS.length];
    private int shzState = 0; // 0 missing, 1 not running, 2 needs permission, 3 ready
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() { refresh(); h.postDelayed(this, 2000); }
    };
    private Shizuku.OnRequestPermissionResultListener permListener;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.init(this);
        P = Ui.pal(this);
        if (Build.VERSION.SDK_INT >= 23 && !Ui.dark(this)) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0));
        }
        buildUi();

        if (Build.VERSION.SDK_INT >= 33
            && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        permListener = (code, res) -> runOnUiThread(this::refresh);
        try { Shizuku.addRequestPermissionResultListener(permListener); } catch (Throwable ignored) { }

        new Thread(() -> {
            Shell.checkRoot();
            if (!Prefs.active()) AfkService.restoreSettings(); // undo leftovers after a crash
            runOnUiThread(this::refresh);
        }).start();
    }

    @Override protected void onResume() { super.onResume(); h.post(ticker); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(ticker); }

    @Override
    protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener); } catch (Throwable ignored) { }
        super.onDestroy();
    }

    private int dp(float v) { return Ui.dp(this, v); }

    // ------------------------------------------------------------------ UI

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(P.bg);
        sv.setFillViewport(true);
        sv.setFitsSystemWindows(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(Ui.tv(this, "Theros AFK Keeper", 26, P.text, true));
        root.addView(Ui.tv(this, "Keep a game running while the screen is off", 13, P.sub, false),
            Ui.lp(-1, -2, 0, dp(2), 0, dp(16)));

        // ---- 1. access
        LinearLayout acc = Ui.card(this, P);
        root.addView(acc);
        acc.addView(Ui.tv(this, "1 \u00b7 Access", 15, P.primary, true));
        accSub = Ui.tv(this, "", 13, P.text, false);
        acc.addView(accSub, Ui.lp(-1, -2, 0, dp(6), 0, dp(4)));
        acc.addView(Ui.tv(this,
            "A real screen-off needs Shizuku (or root). Without it the app falls back to a black, dimmest-brightness screen.",
            12, P.sub, false));
        accBtn = Ui.button(this, "Set up", P.primary, P.onPrimary, v -> accessAction());
        acc.addView(accBtn, Ui.lp(-1, -2, 0, dp(10), 0, 0));

        // ---- 2. target app
        LinearLayout tgt = Ui.card(this, P);
        root.addView(tgt, Ui.lp(-1, -2, 0, dp(10), 0, 0));
        tgt.addView(Ui.tv(this, "2 \u00b7 Game / app", 15, P.primary, true));
        LinearLayout trow = new LinearLayout(this);
        trow.setOrientation(LinearLayout.HORIZONTAL);
        trow.setGravity(Gravity.CENTER_VERTICAL);
        tgtIcon = new ImageView(this);
        trow.addView(tgtIcon, new LinearLayout.LayoutParams(dp(44), dp(44)));
        tgtName = Ui.tv(this, "", 16, P.text, true);
        tgtName.setPadding(dp(12), 0, dp(8), 0);
        trow.addView(tgtName, new LinearLayout.LayoutParams(0, -2, 1f));
        trow.addView(Ui.button(this, "Choose", P.chip, P.primary, v -> openPicker()));
        tgt.addView(trow, Ui.lp(-1, -2, 0, dp(8), 0, 0));
        tgt.addView(Ui.button(this, "Remove background limits for this app", P.chip, P.text, v -> unrestrict()),
            Ui.lp(-1, -2, 0, dp(10), 0, 0));

        // ---- 3. options
        LinearLayout opt = Ui.card(this, P);
        root.addView(opt, Ui.lp(-1, -2, 0, dp(10), 0, 0));
        opt.addView(Ui.tv(this, "3 \u00b7 Options", 15, P.primary, true));
        swOff = new Switch(this);
        opt.addView(switchRow("Turn the screen off", "About 10 seconds after the game opens", swOff), Ui.lp(-1, -2, 0, dp(8), 0, 0));
        swOff.setChecked(Prefs.screenOff());
        swOff.setOnCheckedChangeListener((CompoundButton v, boolean on) -> Prefs.setScreenOff(on));

        swAfk = new Switch(this);
        opt.addView(switchRow("Anti-AFK nudge",
            "Sends a tiny swipe now and then so the game doesn't kick you for idling (needs Shizuku/root)", swAfk),
            Ui.lp(-1, -2, 0, dp(10), 0, 0));
        swAfk.setChecked(Prefs.antiAfk());
        swAfk.setOnCheckedChangeListener((CompoundButton v, boolean on) -> Prefs.setAntiAfk(on));

        opt.addView(Ui.tv(this, "Nudge every", 12, P.sub, false), Ui.lp(-1, -2, 0, dp(10), 0, dp(4)));
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < INTERVALS.length; i++) {
            final int minutes = INTERVALS[i];
            TextView c = Ui.tv(this, minutes + " min", 13, P.text, true);
            c.setPadding(dp(14), dp(8), dp(14), dp(8));
            c.setGravity(Gravity.CENTER);
            c.setClickable(true);
            c.setOnClickListener(v -> { Prefs.setInterval(minutes); refresh(); });
            ivChips[i] = c;
            chipRow.addView(c, Ui.lp(-2, -2, 0, 0, dp(8), 0));
        }
        opt.addView(chipRow);

        // ---- start
        startBtn = Ui.button(this, "Start AFK", P.primary, P.onPrimary, v -> toggleSession());
        startBtn.setTextSize(17);
        startBtn.setPadding(dp(14), dp(16), dp(14), dp(16));
        root.addView(startBtn, Ui.lp(-1, -2, 0, dp(16), 0, 0));

        modeNote = Ui.tv(this, "", 12, P.sub, false);
        root.addView(modeNote, Ui.lp(-1, -2, dp(4), dp(10), dp(4), 0));
        root.addView(Ui.tv(this,
            "Tips: keep the phone plugged in, lower the game's graphics, and press the power button any time to wake the screen. "
                + "Open the notification and tap Stop when you're done \u2014 that restores your normal screen settings.",
            12, P.sub, false), Ui.lp(-1, -2, dp(4), dp(8), dp(4), 0));

        setContentView(sv);
    }

    private View switchRow(String title, String sub, Switch sw) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(Ui.tv(this, title, 15, P.text, true));
        t.addView(Ui.tv(this, sub, 12, P.sub, false), Ui.lp(-1, -2, 0, dp(2), dp(8), 0));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(sw);
        return r;
    }

    // ------------------------------------------------------------------ status

    private boolean installed(String pkg) {
        try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Throwable t) { return false; }
    }

    private void refresh() {
        // access
        String s;
        if (Shell.rootAvailable()) {
            shzState = 3;
            s = "Root detected \u2713 \u2014 full screen-off available";
        } else if (!installed(SHIZUKU_PKG)) {
            shzState = 0;
            s = "Shizuku app is not installed";
        } else {
            shzState = 1;
            s = "Shizuku isn't running \u2014 start it in the Shizuku app";
            try {
                if (Shizuku.pingBinder()) {
                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                        shzState = 3;
                        s = "Shizuku connected \u2713 \u2014 full screen-off available";
                    } else {
                        shzState = 2;
                        s = "Shizuku is running \u2014 tap Grant to allow this app";
                    }
                }
            } catch (Throwable t) { shzState = 1; }
        }
        accSub.setText(s);
        accBtn.setText(shzState == 0 ? "Get Shizuku" : shzState == 1 ? "Open Shizuku" : shzState == 2 ? "Grant" : "Access OK");
        accBtn.setEnabled(shzState != 3);
        Ui.skin(this, accBtn, shzState == 3 ? P.chip : P.primary, shzState == 3 ? P.ok : P.onPrimary, 12);

        // target
        String t = Prefs.target();
        if (t.isEmpty()) {
            tgtName.setText("No app chosen yet");
            tgtIcon.setImageDrawable(null);
        } else {
            try {
                ApplicationInfo ai = getPackageManager().getApplicationInfo(t, 0);
                tgtName.setText(String.valueOf(getPackageManager().getApplicationLabel(ai)));
                tgtIcon.setImageDrawable(getPackageManager().getApplicationIcon(ai));
            } catch (Throwable e) {
                tgtName.setText(t);
            }
        }

        // interval chips
        for (int i = 0; i < INTERVALS.length; i++) {
            boolean sel = INTERVALS[i] == Prefs.interval();
            Ui.skin(this, ivChips[i], sel ? P.primary : P.chip, sel ? P.onPrimary : P.text, 18);
        }

        // start button + note
        boolean active = Prefs.active();
        startBtn.setText(active ? "Stop & wake screen" : "Start AFK");
        Ui.skin(this, startBtn, active ? P.bad : P.primary, active ? 0xFFFFFFFF : P.onPrimary, 12);
        modeNote.setText(shzState == 3
            ? "Mode: real screen-off (display panel off, game keeps running)."
            : "Mode: black-screen fallback (screen stays on but dark). Needs the \u201cdisplay over other apps\u201d permission.");
    }

    private void accessAction() {
        try {
            if (shzState == 0) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")));
            } else if (shzState == 1) {
                Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
                if (i != null) startActivity(i);
            } else if (shzState == 2) {
                Shizuku.requestPermission(31);
            }
        } catch (Throwable t) {
            Toast.makeText(this, "Couldn't open: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------ actions

    private void unrestrict() {
        final String t = Prefs.target();
        if (t.isEmpty()) { Toast.makeText(this, "Choose an app first", Toast.LENGTH_SHORT).show(); return; }
        Toast.makeText(this, "Applying\u2026", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final String log = Boost.apply(this, getPackageName(), t);
            runOnUiThread(() -> showText("Background limits", log));
        }).start();
    }

    private void toggleSession() {
        if (Prefs.active()) {
            AfkService.send(this, AfkService.A_STOP);
            Toast.makeText(this, "Stopping\u2026", Toast.LENGTH_SHORT).show();
            return;
        }
        String t = Prefs.target();
        if (t.isEmpty()) { Toast.makeText(this, "Choose the game first", Toast.LENGTH_SHORT).show(); return; }
        Intent li = getPackageManager().getLaunchIntentForPackage(t);
        if (li == null) { Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show(); return; }
        boolean priv = Shell.active() != Shell.Mode.NONE;
        if (Prefs.screenOff() && !priv && Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \u201cdisplay over other apps\u201d for black-screen mode", Toast.LENGTH_LONG).show();
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (Throwable ignored) { }
            return;
        }
        AfkService.send(this, AfkService.A_START);
        startActivity(li);
        refresh();
    }

    private void showText(String title, String text) {
        TextView t = Ui.tv(this, text, 12, P.text, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setPadding(dp(18), dp(12), dp(18), dp(12));
        ScrollView sv = new ScrollView(this);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("OK", null).show();
    }

    // ------------------------------------------------------------------ picker

    private static final class Item {
        String label, pkg;
        ResolveInfo ri;
    }

    private void openPicker() {
        Toast.makeText(this, "Loading apps\u2026", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> l = pm.queryIntentActivities(i, 0);
            final List<Item> items = new ArrayList<>();
            for (ResolveInfo ri : l) {
                if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                Item it = new Item();
                it.pkg = ri.activityInfo.packageName;
                it.label = String.valueOf(ri.loadLabel(pm));
                it.ri = ri;
                items.add(it);
            }
            Collections.sort(items, new Comparator<Item>() {
                @Override public int compare(Item a, Item b) { return a.label.compareToIgnoreCase(b.label); }
            });
            runOnUiThread(() -> showPicker(items));
        }).start();
    }

    private void showPicker(final List<Item> all) {
        final List<Item> shown = new ArrayList<>(all);
        final PackageManager pm = getPackageManager();
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int p) { return shown.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View cv, ViewGroup parent) {
                Item it = shown.get(p);
                LinearLayout r = new LinearLayout(MainActivity.this);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(dp(16), dp(8), dp(16), dp(8));
                ImageView iv = new ImageView(MainActivity.this);
                iv.setImageDrawable(it.ri.loadIcon(pm));
                r.addView(iv, new LinearLayout.LayoutParams(dp(38), dp(38)));
                LinearLayout t = new LinearLayout(MainActivity.this);
                t.setOrientation(LinearLayout.VERTICAL);
                t.setPadding(dp(12), 0, 0, 0);
                t.addView(Ui.tv(MainActivity.this, it.label, 15, P.text, true));
                t.addView(Ui.tv(MainActivity.this, it.pkg, 11, P.sub, false));
                r.addView(t);
                return r;
            }
        };

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(P.card);
        final EditText search = new EditText(this);
        search.setHint("Search apps");
        search.setSingleLine(true);
        search.setTextColor(P.text);
        search.setHintTextColor(P.sub);
        search.setPadding(dp(18), dp(12), dp(18), dp(12));
        box.addView(search);
        ListView lv = new ListView(this);
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(440)));

        final AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Choose the game / app").setView(box)
            .setNegativeButton("Close", null).create();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable s) {
                String q = s.toString().trim().toLowerCase();
                shown.clear();
                for (Item it : all) {
                    if (q.isEmpty() || it.label.toLowerCase().contains(q) || it.pkg.toLowerCase().contains(q)) shown.add(it);
                }
                ad.notifyDataSetChanged();
            }
        });
        lv.setOnItemClickListener((AdapterView<?> p, View v, int pos, long id) -> {
            Prefs.setTarget(shown.get(pos).pkg);
            dlg.dismiss();
            refresh();
        });
        dlg.show();
    }
}
