package com.theros.afk;

import android.content.Context;

/** Removes Android's background limits for the chosen apps (needs Shizuku or root). */
final class Boost {
    static String apply(Context c, String... pkgs) {
        Shell.Mode m = Shell.active();
        if (m == Shell.Mode.NONE) return "No Shizuku or root access yet.";
        StringBuilder sb = new StringBuilder("Mode: " + m + "\n");
        int ok = 0, total = 0;
        for (String pkg : pkgs) {
            if (pkg == null || pkg.isEmpty()) continue;
            int uid;
            try {
                uid = c.getPackageManager().getApplicationInfo(pkg, 0).uid;
            } catch (Throwable t) {
                sb.append("\n").append(pkg).append(" is not installed\n");
                continue;
            }
            sb.append("\n").append(pkg).append("\n");
            String[] cmds = new String[]{
                "cmd deviceidle whitelist +" + pkg,
                "cmd appops set " + pkg + " RUN_IN_BACKGROUND allow",
                "cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow",
                "am set-standby-bucket " + pkg + " active",
                "cmd netpolicy add restrict-background-whitelist " + uid
            };
            for (String cmd : cmds) {
                total++;
                Shell.Res r = Shell.run(cmd);
                boolean good = r.code == 0;
                if (good) ok++;
                sb.append(good ? "\u2713 " : "\u2717 ").append(cmd).append('\n');
            }
        }
        String[] global = new String[]{
            "settings put global settings_enable_monitor_phantom_procs false",
            "device_config set_sync_disabled_for_tests persistent",
            "device_config put activity_manager max_phantom_processes 2147483647",
            "settings put global cached_apps_freezer disabled"
        };
        sb.append("\nSystem-wide\n");
        for (String cmd : global) {
            total++;
            Shell.Res r = Shell.run(cmd);
            boolean good = r.code == 0;
            if (good) ok++;
            sb.append(good ? "\u2713 " : "\u2717 ").append(cmd).append('\n');
        }
        sb.append("\n").append(ok).append(" of ").append(total).append(" steps applied (unsupported ones are skipped).");
        return sb.toString();
    }
}
