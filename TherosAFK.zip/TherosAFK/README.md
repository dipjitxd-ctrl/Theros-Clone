# Theros AFK Keeper
Keeps a game (e.g. Roblox) running while the screen is off.
* Shizuku/root: turns the display PANEL off (`cmd display power-off 0`) while the phone stays awake, so the game keeps running.
* No Shizuku/root: black, dimmest-brightness overlay (screen is technically on).
* Optional anti-AFK nudge (tiny swipe every few minutes) and background-limit removal for the chosen app.
debug.keystore = permanent signing key (copied to ~/.android by the workflow).
